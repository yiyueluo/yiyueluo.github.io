"use strict";

//include frontend code:
const knitout = require('knitout');

//set up a knitout writer:
let k = new knitout.Writer({
	carriers:['1','2','3','4','5','6','7','8','9','10'] //let the writer know the names of the carriers on the machine
});


const Carrier = '9';
const plateCarrier = '8';
const condCarrier = '7';
const Width = 200;
//pattern will be tiled to Width/Height:
const Pattern = [
	'fb',
	'bf'
];

const min = 0;
const max = Width;
const needleStride = 2;


function caston_tube(main){
	k.inhook(main);
	for (let n = max/needleStride; n >= min/needleStride; --n)
		if ((max/2-n)%2 === 0) k.tuck("-", "f" + n * needleStride, main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		if ((max/2-n)%2 !== 0) k.tuck("+", "f" + n * needleStride, main);

    for (let n = max/needleStride; n >= min/needleStride; --n)
		if ((max/2-n)%2 === 0) k.tuck("-", "b" + (n * needleStride +1), main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		if ((max/2-n)%2 !== 0) k.tuck("+", "b" + (n * needleStride +1), main);

	for (let n = max/needleStride; n >= min/needleStride; --n)
		k.knit("-", "f" + n * needleStride, main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		k.knit("+", "f" + n * needleStride, main);

    for (let n = max/needleStride; n >= min/needleStride; --n)
		k.knit("-", "b" + (n * needleStride +1), main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		k.knit("+", "b" + (n * needleStride +1), main);
	k.releasehook(main);
}

function caston_front(main){
	k.inhook(main);
	for (let n = max/needleStride; n >= min/needleStride; --n)
		if ((max/2-n)%2 === 0) k.tuck("-", "f" + n * needleStride, main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		if ((max/2-n)%2 !== 0) k.tuck("+", "f" + n * needleStride, main);

	for (let n = max/needleStride; n >= min/needleStride; --n)
		k.knit("-", "f" + n * needleStride, main);

	for (let n = min/needleStride; n <= max/needleStride; ++n)
		k.knit("+", "f" + n * needleStride, main);
	k.releasehook(main);
}

function tuckIn (yarn, location) {
    k.inhook(yarn);
    k.tuck("-", "f" + (location*needleStride+2), yarn);
    k.tuck("-", "f" + (location*needleStride+0), yarn);
    k.tuck("+", "f" + (location*needleStride+1), yarn);
    k.knit("-", "f" + (location*needleStride+2), yarn);
    k.knit("-", "f" + (location*needleStride+0), yarn);
    k.knit("+", "f" + (location*needleStride+1), yarn);
    k.releasehook(yarn);
}

function drop_tuckIn (location) {
    k.drop("f" + (location*needleStride+2));
    k.drop("f" + (location*needleStride+0));
    k.drop("f" + (location*needleStride+1));
    k.drop("f" + (location*needleStride+2));
    k.drop("f" + (location*needleStride+0));
    k.drop("f" + (location*needleStride+1));
}

function normal_tube(l, hi, lo){
	for (let c = 0; c < l; c++) {
		for (let n = hi/needleStride; n >= lo; --n){
			k.knit("-", "f" + n * needleStride, Carrier);
		}
		for (let n = lo; n <= hi/needleStride; ++n){
			k.knit("+", "b" + (n * needleStride +1), Carrier);
		}
	}
}

function square_tube(l, hi, lo, subhi, sublo, cmain, cplate){
	for (let c = 0; c <= l/4; c++) {
		for (let n = hi/needleStride; n > subhi/needleStride; --n){
			k.knit("-", "f" + n * needleStride, cmain);
		}

		for (let n = subhi/needleStride; n >= sublo/needleStride; --n){
			k.knit("-", "f" + n * needleStride, cmain, cplate);
		}

		for (let n = sublo/needleStride-1; n >= lo; --n){
			k.knit("-", "f" + n * needleStride, cmain);
		}

		for (let n = lo; n <= hi/needleStride; ++n){
			k.knit("+", "b" + (n * needleStride +1), cmain);
		}
		for (let n = hi/needleStride; n >= lo; --n){
			k.knit("-", "b" + (n * needleStride +1), cmain);
		}

		for (let n = lo; n < sublo/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain);
		}

		for (let n = sublo/needleStride; n <= subhi/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain, cplate);
		}

		for (let n = subhi/needleStride+1; n <= hi/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain);
		}

		for (let n = hi/needleStride; n >= lo; --n){
			k.knit("-", "b" + (n * needleStride +1), cmain);
		}

		for (let n = lo; n <= hi/needleStride; ++n){
			k.knit("+", "b" + (n * needleStride +1), cmain);
		}
		for (let n = hi/needleStride; n > subhi/needleStride; --n){
			k.knit("-", "f" + n * needleStride, cmain);
		}

		for (let n = subhi/needleStride; n >= sublo/needleStride; --n){
			k.knit("-", "f" + n * needleStride, cmain, cplate);
		}

		for (let n = sublo/needleStride-1; n >= lo; --n){
			k.knit("-", "f" + n * needleStride, cmain);
		}

		for (let n = lo; n < sublo/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain);
		}

		for (let n = sublo/needleStride; n <= subhi/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain, cplate);
		}

		for (let n = subhi/needleStride+1; n <= hi/needleStride; ++n){
			k.knit("+", "f" + n * needleStride, cmain);
		}

	}
}

function normal(l, hi, lo){
	for (let c = 0; c < l; c++) {
		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 !== 0) {
				k.xfer("f" + n * needleStride, "b" + n * needleStride);
			}
		}

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 !== 0) {
				k.knit("-", "b" + n * needleStride, Carrier);
			} else {
				k.knit("-", "f" + n * needleStride, Carrier);
			}
		}

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 !== 0) {
				k.xfer("b" + n * needleStride, "f" + n * needleStride);
			}
		}

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 === 0) {
				k.xfer("f" + n * needleStride, "b" + n * needleStride);
			}
		}

		for (let n = lo/needleStride; n <= hi / needleStride; ++n) {
			if (n % 2 === 0) {
				k.knit("+", "b" + n * needleStride, Carrier);
			} else {
				k.knit("+", "f" + n * needleStride, Carrier);
			}
		}

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 === 0) {
				k.xfer("b" + n * needleStride, "f" + n * needleStride);
			}
		}
	}
}

function square_list(l, hi, lo, subhi_list, sublo_list, npatch, cmain, cplate){
	for (let c = 0; c <= l/2; c++) {
		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 !== 0) {
				k.xfer("f" + n * needleStride, "b" + n * needleStride);
			}
		}

        for (let n = hi / needleStride; n >= subhi_list[0] / needleStride; --n) {
			if (n % 2 !== 0) {
				k.knit("-", "b" + n * needleStride, cmain);
			}
			else {
				k.knit("-", "f" + n * needleStride, cmain);
			}
        }

		for (let lc = 0; lc<subhi_list.length-1; lc++){
			for (let n = subhi_list[lc] / needleStride; n >= sublo_list[lc] / needleStride; --n) {
				if (n % 2 !== 0) {
					k.knit("-", "b" + n * needleStride, cmain, cplate);
				} else {
					k.knit("-", "f" + n * needleStride, cmain, cplate);
				}
			}

			for (let n = sublo_list[lc] / needleStride; n >= subhi_list[lc+1] / needleStride; --n) {
				if (n % 2 !== 0) {
					k.knit("-", "b" + n * needleStride, cmain);
				}
				else {
					k.knit("-", "f" + n * needleStride, cmain);
				}
			}
		}


		for (let n = subhi_list[npatch-1] / needleStride; n >= sublo_list[npatch-1] / needleStride; --n) {
			if (n % 2 !== 0) {
				k.knit("-", "b" + n * needleStride, cmain, cplate);
			} else {
				k.knit("-", "f" + n * needleStride, cmain, cplate);
			}
		}

		for (let n = sublo_list[npatch-1] / needleStride; n >= lo / needleStride; --n) {
			if (n % 2 !== 0) {
				k.knit("-", "b" + n * needleStride, cmain);
			}
			else {
				k.knit("-", "f" + n * needleStride, cmain);
			}
		}


		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 !== 0) {
				k.xfer("b" + n * needleStride, "f" + n * needleStride);
			}
		}

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 === 0) {
				k.xfer("f" + n * needleStride, "b" + n * needleStride);
			}
		}

        for (let n = lo / needleStride; n <= sublo_list[npatch-1] / needleStride; ++n) {
			if (n % 2 === 0) {
				k.knit("+", "b" + n * needleStride, cmain);
			}
			else {
				k.knit("+", "f" + n * needleStride, cmain);
			}
        }


		for (let lc = subhi_list.length; lc>0; lc--){
			for (let n = sublo_list[lc] / needleStride; n <= subhi_list[lc] / needleStride; ++n) {
				if (n % 2 !== 0) {
					k.knit("+", "f" + n * needleStride,  cmain, cplate);
				} else {
					k.knit("+", "b" + n * needleStride, cmain, cplate);
				}
			}

			for (let n = subhi_list[lc] / needleStride; n <= sublo_list[lc-1] / needleStride; ++n) {
				if (n % 2 !== 0) {
					k.knit("+", "f" + n * needleStride, cmain);
				}
				else {
					k.knit("+", "b" + n * needleStride, cmain);
				}
			}
		}

        for (let n = sublo_list[0] / needleStride; n <= subhi_list[0] / needleStride; ++n) {
			if (n % 2 === 0) {
				k.knit("+", "b" + n * needleStride, cmain, cplate);
			}
			else {
				k.knit("+", "f" + n * needleStride, cmain, cplate);
			}
        }


        for (let n = subhi_list[0] / needleStride; n <= hi / needleStride; ++n) {
			if (n % 2 === 0) {
				k.knit("+", "b" + n * needleStride, cmain);
			}
			else {
				k.knit("+", "f" + n * needleStride, cmain);
			}
        }

		for (let n = hi / needleStride; n >= lo/needleStride; --n) {
			if (n % 2 === 0) {
				k.xfer("b" + n * needleStride, "f" + n * needleStride);
			}
		}

    }
}

function pocket(l, hi, lo, subhi, sublo){
	for (let n = subhi / needleStride; n >= sublo / needleStride; --n) {
		if (n%2 === 0){
			k.xfer("f" + n * needleStride, "b" + n * needleStride);
		}
	}

	for (let c = 0; c < l; c++) {
		if (c === 0){
			for (let n = hi/needleStride; n >= lo/needleStride; --n){
				if (n <= subhi/needleStride && n >= sublo/needleStride && n%2===0){
					k.tuck("-", "f" + n * needleStride, Carrier);
				}
				else {
					k.knit("-", "f" + n * needleStride, Carrier);
				}
			}

			for (let n = lo/needleStride; n <= hi/needleStride; ++n){
			    k.knit("+", "f" + n * needleStride, Carrier);
			}

			for (let n = hi / needleStride; n >= subhi/needleStride; --n) {
				k.knit("-", "f" + n * needleStride, Carrier);
			}

			for (let n = subhi / needleStride; n > sublo/needleStride; --n) {
				if (n%2!==0){
					k.tuck("-", "b" + n * needleStride, Carrier);
				}
				else {
					k.knit("-", "b" + n * needleStride, Carrier);
				}
			}

			for (let n = sublo / needleStride; n > lo/needleStride; --n) {
				k.knit("-", "f" + n * needleStride, Carrier);
			}

			for (let n = lo/needleStride; n < sublo/needleStride; ++n){
			    k.knit("+", "f" + n * needleStride, Carrier);
			}

			for (let n = sublo/needleStride; n < subhi/needleStride; ++n){
			    k.knit("+", "b" + n * needleStride, Carrier);
			}

			for (let n = subhi/needleStride; n <= hi/needleStride; ++n){
			    k.knit("+", "f" + n * needleStride, Carrier);
			}

		}

		else {
			for (let n = hi / needleStride; n >= lo/needleStride; --n) {
				if ((n < sublo/needleStride || n > subhi/needleStride) && n % 2 !== 0) {
					k.xfer("f" + n * needleStride, "b" +  n * needleStride);
				}
			}

			for (let n = hi/ needleStride; n > subhi / needleStride; --n) {
				if (n % 2 !== 0) {
					k.knit("-", "b" + n * needleStride, Carrier);
				}
				else {
					k.knit("-", "f" + n * needleStride, Carrier);
				}
			}


			for (let n = subhi/ needleStride; n >= sublo / needleStride; --n) {
				k.knit("-", "f" + n * needleStride, Carrier);
			}

			for (let n = sublo / needleStride; n <= subhi / needleStride; ++n) {
				k.knit("+", "b" + n * needleStride, Carrier);
			}

			for (let n = subhi / needleStride; n >= sublo / needleStride; --n) {
				k.knit("-", "f" + n * needleStride, Carrier);
			}


			for (let n = sublo / needleStride -1; n >= lo / needleStride; --n) {
				if (n % 2 !== 0) {
					k.knit("-", "b" + n * needleStride, Carrier);
				}
				else {
					k.knit("-", "f" + n * needleStride, Carrier);
				}
			}


			for (let n = hi / needleStride; n >= lo/needleStride; --n) {
				if  ((n < sublo/needleStride || n > subhi/needleStride) && n % 2 !== 0) {
					k.xfer("b" + n * needleStride, "f" + n * needleStride);
				}
			}

			for (let n = hi / needleStride; n >= lo/needleStride; --n) {
				if  ((n < sublo/needleStride || n > subhi/needleStride) && n % 2 === 0) {
					k.xfer("f" + n * needleStride, "b" + n * needleStride);
				}
			}


			for (let n = lo / needleStride; n <= sublo / needleStride; ++n) {
				if (n % 2 === 0) {
					k.knit("+", "b" + n * needleStride, Carrier);
				}
				else {
					k.knit("+", "f" + n * needleStride, Carrier);
				}
			}
			for (let n = sublo / needleStride + 1; n <= subhi / needleStride; ++n) {
				k.knit("+", "b" + n * needleStride, Carrier);
			}
			for (let n = subhi / needleStride + 1; n <= hi / needleStride; ++n) {
				if (n % 2 === 0) {
					k.knit("+", "b" + n * needleStride , Carrier);
				}
				else {
					k.knit("+", "f" + n * needleStride , Carrier);
				}
			}

			for (let n = hi / needleStride; n >= lo/needleStride; --n) {
				if  ((n < sublo/needleStride || n > subhi/needleStride) && n % 2 === 0){
					k.xfer("b" + n * needleStride, "f" + n * needleStride );
				}
			}
		}
	}

	for (let n = hi / needleStride; n >= subhi / needleStride; --n) {
		k.knit("-", "f" + n * needleStride, Carrier);
	}

	for (let c = 0; c < 6; c++) {
		for (let n = subhi / needleStride; n >= sublo / needleStride; --n) {
			k.knit("-", "b" + n * needleStride, Carrier);
		}

		for (let n = sublo / needleStride; n <= subhi / needleStride; ++n) {
			k.knit("+", "b" + n * needleStride, Carrier);
		}

	}

	for (let n = subhi / needleStride; n <= hi / needleStride; ++n) {
		k.knit("+", "f" + n * needleStride, Carrier);
	}

	for (let n = sublo/needleStride; n <= subhi/needleStride; ++n)
		k.drop("b" + n * needleStride);

}

// flat sheet magnet patch
// caston_front(Carrier);
// normal(10, max, min);
// tuckIn(plateCarrier, max/2 +3);
// // square_list(6, max, min, [159+5, 119+5, 79+5, 39+5], [159-5, 119-5, 79-5, 39-5], 4, Carrier, plateCarrier);
// square_list(6, max, min, [60], [10], 1, Carrier, plateCarrier);
// drop_tuckIn(max/2 +3);
// normal(10, max, min);

// flat sheet pocket
// caston_front(Carrier);
// normal(10, max, min);
// tuckIn(plateCarrier, max/2 +3);
// pocket(6, max, min, 60, 10);
// drop_tuckIn(max/2 +3);
// normal(10, max, min);
//

//tubular magnet patch
caston_tube(Carrier);
normal_tube(10, max, min);
tuckIn(plateCarrier, max/2 +3);
square_tube(6, max, min, 60, 10, Carrier, plateCarrier);
drop_tuckIn(max/2 +3);
normal_tube(10, max, min);



for (let n = min; n <= max/needleStride; ++n)
	k.drop("b" + (n * needleStride + 1));

for (let n = min; n <= max/needleStride; ++n)
	k.drop("f" + n * needleStride);

k.write("UI.k");