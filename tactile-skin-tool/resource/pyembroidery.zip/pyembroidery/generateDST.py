from generateDST_utils import *
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--input_path', type=str, default='./SVG/set2.svg', help='input file path') # define input file
parser.add_argument('--output_path', type=str, default='./output/', help='output path')
parser.add_argument('--output_name', type=str, default='set2.dst', help='output file name') # define output file
parser.add_argument('--pitch', type=int, default=40, help='pitch') # unit in 0.1mm
parser.add_argument('--viz', type=bool, default=True, help='viz')
parser.add_argument('--scale', type=float, default=10, help='design scale')
parser.add_argument('--reverse', type=bool, default=False, help='direction for single path')
args = parser.parse_args()

pattern = pyembroidery.EmbPattern()

x_all, y_all = extract_pt_from_svg(args.input_path, args.scale,
                                   viz=False, target_units='mm')
print ('control points extracted from svg')
print (len(x_all))

'''single path'''
if len(x_all) == 1:
    x_pos_all = []
    y_pos_all = []

    if args.reverse:
        for i in range(len(x_all[0])-1, 0, -1):
            if i%2 != 0:
                x, y = draw_line(pattern, [x_all[0][i], y_all[0][i]], [x_all[0][i - 1], y_all[0][i - 1]],
                                 args.pitch, endpoint=False)
            x_pos_all += x
            y_pos_all += y

    else:
        for i in range(len(x_all[0])-1):
            if i%2 == 0:
                x, y = draw_line(pattern, [x_all[0][i], y_all[0][i]], [x_all[0][i+1], y_all[0][i+1]],
                                 args.pitch, endpoint=False)
            x_pos_all += x
            y_pos_all += y
            
    pyembroidery.write_dst(pattern, args.output_path + args.output_name)
    print ('single path, pitch=', args.pitch, ', ', args.output_path + args.output_name, 'saved')
    if args.viz:
        print (len(x_pos_all))
        print (x_pos_all[0], y_pos_all[0])
        marker_size = (max(x_pos_all)-min(x_pos_all))
        plt.scatter(x_pos_all, y_pos_all, c='#FFC514', s=5)
        for i in range(len(x_pos_all)-1):
            plt.plot([x_pos_all[i], x_pos_all[i+1]], [y_pos_all[i], y_pos_all[i+1]], c='#FFC514', linewidth=1)
        plt.show()


'''two crossing paths'''
if len(x_all) == 2:
    x_pos_all = [[],[]]
    y_pos_all = [[],[]]
    print (len(x_all[0]), len(x_all[1]))
    x, y = drawline_halfway_1(pattern, x_all, y_all, pitch=args.pitch)
    x_pos_all[0] += x
    y_pos_all[0] += y
    pattern.color_change()
    x, y = drawline_halfway_2(pattern, x_all, y_all, pitch=args.pitch)
    x_pos_all[1] += x
    y_pos_all[1] += y

    pyembroidery.write_dst(pattern, args.output_path + args.output_name)
    print ('two paths, pitch=', args.pitch, ', ', args.output_path + args.output_name, 'saved')

    if args.viz:
        print(x_pos_all[0][0], y_pos_all[0][0], x_pos_all[1][0], y_pos_all[1][0])
        # marker_size = (max(x_pos_all[0])-min(x_pos_all[0]))
        # print (x_pos_all[0])
        plt.scatter(x_pos_all[0], y_pos_all[0], c='green', s=1)
        for i in range(len(x_pos_all[0])-1):
            plt.plot([x_pos_all[0][i], x_pos_all[0][i+1]], [y_pos_all[0][i], y_pos_all[0][i+1]])
        plt.scatter(x_pos_all[1], y_pos_all[1], c='blue', s=1)
        for i in range(len(x_pos_all[1])-1):
            plt.plot([x_pos_all[1][i], x_pos_all[1][i+1]], [y_pos_all[1][i], y_pos_all[1][i+1]])
        plt.show()



